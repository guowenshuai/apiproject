#########################################################################
# File Name: build.sh
# Author: WenShuai
# mail: guowenshuai8207@163.com
# Created Time: Mon 25 Jun 2018 06:44:26 PM CST
#########################################################################
#!/bin/bash
docker build -t wenshuai/apiproject .
